/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author MRuser
 */
public class Customer {
    private String UserName;
    private String Password;
    private String Name;
    private String Email_Id;
    public Customer(String un,String pass,String nm,String eID)
    {
        UserName=un;
        Password=pass;
        Name=nm;
        Email_Id=eID;
    }

    /**
     * @return the UserName
     */
    public String getUserName() {
        return UserName;
    }

    /**
     * @param UserName the UserName to set
     */
    public void setUserName(String UserName) {
        this.UserName = UserName;
    }

    /**
     * @return the Password
     */
    public String getPassword() {
        return Password;
    }

    /**
     * @param Password the Password to set
     */
    public void setPassword(String Password) {
        this.Password = Password;
    }

    /**
     * @return the Name
     */
    public String getName() {
        return Name;
    }

    /**
     * @param Name the Name to set
     */
    public void setName(String Name) {
        this.Name = Name;
    }

    /**
     * @return the Email_Id
     */
    public String getEmail_Id() {
        return Email_Id;
    }

    /**
     * @param Email_Id the Email_Id to set
     */
    public void setEmail_Id(String Email_Id) {
        this.Email_Id = Email_Id;
    }
    
}
