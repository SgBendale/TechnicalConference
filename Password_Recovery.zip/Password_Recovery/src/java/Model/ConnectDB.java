/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.*;

/**
 *
 * @author MRuser
 */
public class ConnectDB {
    Connection con;
    ResultSet rs;
    Statement stmt;
    public Connection connect()throws ClassNotFoundException,SQLException
    {
        Class.forName("org.apache.derby.jdbc.DerbyClient");
        con=DriverManager.getConnection("jdbc:derby://localhost:1527/sample");
        return con;       
    }
    
    
}
